package com.foodsharing.foodsharing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodsharingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodsharingApplication.class, args);
	}

}
